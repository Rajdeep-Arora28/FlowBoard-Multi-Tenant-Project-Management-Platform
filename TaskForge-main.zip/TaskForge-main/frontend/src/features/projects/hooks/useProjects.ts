'use client';

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  projectsApi,
  type CreateProjectPayload,
  type UpdateProjectPayload,
} from '@/lib/api/projects.api';
import { useOrgWorkspaceContext } from '@/features/organizations/hooks/useOrgWorkspaceContext';
import type { PaginationParams } from '@/types';

export interface ProjectListParams extends PaginationParams {
  search?: string;
}

function normalizeParams(params?: ProjectListParams): ProjectListParams | undefined {
  if (!params) return undefined;
  return {
    ...params,
    search: params.search?.trim() || undefined,
  };
}

export const projectKeys = {
  all: ['projects'] as const,
  list: (params?: ProjectListParams) => ['projects', 'list', normalizeParams(params)] as const,
  detail: (id: string) => ['projects', 'detail', id] as const,
};

export function useProjects(params?: ProjectListParams) {
  const normalized = normalizeParams(params);
  const { hasValidOrgContext } = useOrgWorkspaceContext();

  return useQuery({
    queryKey: projectKeys.list(normalized),
    queryFn: () => projectsApi.list(normalized).then((r) => r.data),
    enabled: hasValidOrgContext,
  });
}

export function useProject(id: string) {
  const { hasValidOrgContext } = useOrgWorkspaceContext();

  return useQuery({
    queryKey: projectKeys.detail(id),
    queryFn: () => projectsApi.getById(id).then((r) => r.data.data!),
    enabled: !!id && hasValidOrgContext,
  });
}

export function useCreateProject() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (payload: CreateProjectPayload) => projectsApi.create(payload),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: projectKeys.all });
    },
  });
}

export function useUpdateProject() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({ id, payload }: { id: string; payload: UpdateProjectPayload }) =>
      projectsApi.update(id, payload),
    onSuccess: (_, { id }) => {
      queryClient.invalidateQueries({ queryKey: projectKeys.all });
      queryClient.invalidateQueries({ queryKey: projectKeys.detail(id) });
    },
  });
}

export function useDeleteProject() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (id: string) => projectsApi.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: projectKeys.all });
    },
  });
}
