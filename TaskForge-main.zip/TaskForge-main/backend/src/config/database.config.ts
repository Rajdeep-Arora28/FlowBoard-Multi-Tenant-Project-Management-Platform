import { registerAs } from '@nestjs/config';
import { getPostgresSslConfig } from './db-ssl';

export default registerAs('database', () => ({
  host: process.env.DB_HOST || 'localhost',
  port: parseInt(process.env.DB_PORT ?? '5432', 10),
  username: process.env.DB_USERNAME || 'postgres',
  password: process.env.DB_PASSWORD || 'password',
  database: process.env.DB_NAME || 'taskforge',
  ssl: getPostgresSslConfig(),
}));
